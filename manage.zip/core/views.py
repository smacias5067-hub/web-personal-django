from django.shortcuts import render
from .models import Persona, Project


def home(request):

    persona = Persona.objects.first()

    return render(request, 'home.html', {
        'persona': persona
    })


def about(request):

    persona = Persona.objects.first()

    return render(request, 'about.html', {
        'persona': persona
    })


def portfolio(request):

    persona = Persona.objects.first()

    projects = Project.objects.all()

    return render(request, 'portfolio.html', {
        'persona': persona,
        'projects': projects
    })


def contact(request):

    persona = Persona.objects.first()

    return render(request, 'contact.html', {
        'persona': persona
    })