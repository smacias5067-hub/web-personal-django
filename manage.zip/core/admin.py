from django.contrib import admin
from .models import Persona, Project


admin.site.register(Persona)
admin.site.register(Project)
