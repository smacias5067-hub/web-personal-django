from django.db import models

class Persona(models.Model):

    nombres = models.CharField(max_length=100)

    apellidos = models.CharField(max_length=100)

    direccion = models.CharField(max_length=200)

    telefono = models.CharField(max_length=20)

    titulo_academico = models.CharField(max_length=100)

    biografia = models.TextField()

    correo_electronico = models.EmailField()

    dedicacion_persona = models.CharField(max_length=100)

    instagram = models.URLField(blank=True, null=True)
    youtube = models.URLField(blank=True, null=True)
    github = models.URLField(blank=True, null=True)

    def __str__(self):
        return self.nombres + " " + self.apellidos


class Project(models.Model):

    titulo = models.CharField(max_length=200)

    descripcion = models.TextField()

    imagen = models.ImageField(upload_to='projects')

    created = models.DateTimeField(auto_now_add=True)

    updated = models.DateTimeField(auto_now=True)

    class Meta:

        verbose_name = 'proyecto'

        verbose_name_plural = 'proyectos'

    def __str__(self):

        return self.titulo